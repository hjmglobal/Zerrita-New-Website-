# Zerrita LLC Website

This repository contains the landing page for **Zerrita LLC**, a global ecommerce, accounting, and logistics company.

## 📂 Files
- `index.html` — The website landing page (self-contained HTML + CSS).
- `README.md` — This file with deployment instructions.

## 🚀 Deploy on GitHub Pages

1. Go to [GitHub.com](https://github.com) and create a new repository named, for example, `zerrita-website`.
2. Upload `index.html` and `README.md` to the repository (you can drag and drop them in the GitHub web interface).
3. In the repository, go to **Settings → Pages**.
4. Under **Branch**, select `main` (or `master`) and the root (`/`) folder.
5. Click **Save**. GitHub Pages will publish your site in a few minutes.
6. Your site will be live at `https://yourusername.github.io/zerrita-website`.

## 🧰 Edit Locally

To edit on macOS, you can use **TextEdit** (the Notepad equivalent) or code editors like **Visual Studio Code** or **Sublime Text**.

---
**Zerrita LLC**
6101 Palm Trace Landings DR Apt 111, Davie, Florida, USA, 33314
